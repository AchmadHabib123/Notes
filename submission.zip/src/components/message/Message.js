import React from 'react';

function Message() {
    return <p className='notes-blank-message'>~Catatan Kosong.~</p>
}

export default Message;